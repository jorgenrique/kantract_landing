# Landing page (pre launch)

Files to upload to hosting (minimized):
- index.html
- error.html
- style_min.css

Source files (Do not include in host):
- source.html
- error_source.html
- scss root folder (output is style.css)
